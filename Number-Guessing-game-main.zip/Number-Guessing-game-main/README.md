<h1 align="center"><b>🕹Number Guessing Game<br>Test your Guesses
 </b></h1>
<h2 align="center"><u><b>A one hour build; Terminal based number guessing game</u></b></h3>


----------------------------

  <p>
    <h2><u><b> features</u></b> </h2>
    &bull; Levels <br>
    &bull; Computer Multiplayer <br>
    &bull; point system <br>
 </p>
 
 <p>
   <h2><u><b> How to play?</b></u></h3> 
   &bull; Enter a number as level, Number of chances available and max range depent on this <br>
   &bull; Select Mode: single player or Multiplayer <br>
   &bull; Enter your guess <br>
   &bull; Guess the actual number based on given hints <br>
  </p>
 
 <h2 align='left'><u><b>Version</u></b></h2>
 Version 1.0
 
 <h2><u><b>Installation</u></b></h2>
 
 Install using git bash<code> $git clone https://github.com/Akshay-Vs/Number-Guessing-game.git </code><br>
 os click download button 👇 <br>
 <a href="https://github.com/Akshay-Vs/Number-Guessing-game/archive/refs/heads/main.zip" target="blank"><img align="center" src="https://github.com/Akshay-Vs/resources/blob/main/src/download_bt.png" alt="blank" height="78" width="200" /></a>
 
<h2 align="left"><b>Connect with me</b></h4>
<p align="left">
<a href="https://twitter.com/@Akshayv69128812" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="@Akshayv69128812" height="30" width="40" /></a>
<a href="https://stackoverflow.com/users/akshay-vs" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/stack-overflow.svg" alt="akshay-vs" height="30" width="40" /></a>
<a href="https://instagram.com/akshay._.vs__" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="__akshay_v5__" height="30" width="40" /></a>
</p>
 
<h2 align='left'><u><b>License and Copyright</b></u></h2>
Lisence: MIT Lisence<br>
&#169; 2021 Akshay Vs
